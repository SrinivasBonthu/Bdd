package PageBean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class ConferenceRegistrationPageFactory {
	WebDriver driver;

	// step 1 : identify elements
	@FindBy(name = "txtFN")
	@CacheLookup
	WebElement pffname;

	@FindBy(xpath = "/html/body/form/table/tbody/tr[14]/td/a")
	@CacheLookup
	WebElement pfbutton;

	@FindBy(name = "txtLN")
	@CacheLookup
	WebElement pflname;

	@FindBy(name = "Email")
	@CacheLookup
	WebElement pfemail;

	@FindBy(name = "Phone")
	@CacheLookup
	WebElement pfmobile;

	@FindBy(name="size")
	@CacheLookup
	WebElement pfpersons;

	@FindBy(name = "Address")
	@CacheLookup
	WebElement pfAddress;

	@FindBy(name = "Address2")
	@CacheLookup
	WebElement pfAddress2;

	@FindBy(how = How.NAME, using = "city")
	@CacheLookup
	WebElement pfcity;

	@FindBy(how = How.NAME, using = "state")
	@CacheLookup
	WebElement pfstate;

	@FindBy(name = "memberStatus")
	@CacheLookup
	WebElement pfmemberStatus;

	// initiating Elements
	public ConferenceRegistrationPageFactory(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	// step 2 : Setters
	
	public WebElement getPffname() {
		return pffname;
	}

	public void setPffname(String sfname) {
		pffname.sendKeys(sfname);
	}

	public WebElement getPfbutton() {
		return pfbutton;
	}

	public void setPfbutton() {
		pfbutton.click();
	}

	public WebElement getPflname() {
		return pflname;
	}

	public void setPflname(String sflname) {
		pflname.sendKeys(sflname);
	}

	public WebElement getPfemail() {
		return pfemail;
	}

	public void setPfemail(String sfemail) {
		pfemail.sendKeys( sfemail); 
	}

	public WebElement getPfmobile() {
		return pfmobile;
	}

	public void setPfmobile(String sfmobile) {
		pfmobile.sendKeys(sfmobile);
	}

	public WebElement getPfpersons() {
		return pfpersons;
	}

	public void setPfpersons(String sfpersons) {
		pfpersons.sendKeys(sfpersons);
	}

	public WebElement getPfAddress() {
		return pfAddress;
	}

	public void setPfAddress(String sfAddress) {
		pfAddress.sendKeys(sfAddress);
	}

	public WebElement getPfAddress2() {
		return pfAddress2;
	}

	public void setPfAddress2(String sfAddress2) {
		pfAddress2.sendKeys(sfAddress2);
	}

	public WebElement getPfcity() {
		return pfcity;
	}

	public void setPfcity(String sfcity) {
		pfcity.sendKeys(sfcity);
	}

	public WebElement getPfstate() {
		return pfstate;
	}

	public void setPfstate(String sfstate) {
	   pfstate.sendKeys(sfstate);
	}

	public WebElement getPfmemberStatus() {
		return pfmemberStatus;
	}

	public void setPfmemberStatus () {
		pfmemberStatus.click();
	}

}
