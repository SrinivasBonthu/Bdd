package PersonalDetails;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import PageBean.PersonalDetailsPageFactory;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class PersonalDetailsStepDef {


	private static WebDriver driver;
	private  PersonalDetailsPageFactory objhbpg;
	String BaseURL,NodeURL;
	

	@Before
	public void beforeLogin()
	{
		System.setProperty("webdriver.chrome.driver","D:\\chromedriver.exe");
		driver = new ChromeDriver();
	}
	
	
	@Given("^User is on 'PersonalDetails' Page$")
	public void user_is_on_PersonalDetails_Page() throws Throwable {
	System.out.println("driver = "+driver);
		
		objhbpg = new  PersonalDetailsPageFactory(driver);
		driver.get("file:///C:/Users/admin/Desktop/Registration/PaymentDetails.html");
	}

	@Then("^Verify The title of the page$")
	public void verify_The_title_of_the_page() throws Throwable {
		
	String title=driver.getTitle();
			if(title.contentEquals("Payment Details")) System.out.println("****** Title Matched");
			else System.out.println("****** Title NOT Matched");
			driver.close();
		}

	@When("^user Clicks MakePayment without 'CardHolderName'$")
	public void user_Clicks_MakePayment_without_CardHolderName() throws Throwable {
		objhbpg.setPfcardholder("");
		objhbpg.setPfbutton();
	}

	@Then("^display 'Please fill the CardHolderName'$")
	public void display_Please_fill_the_CardHolderName() throws Throwable {
		 Assert.assertEquals(driver.switchTo().alert().getText(), "Please fill the Card holder name");
	}

	@When("^user Clicks MakePayment without 'DebitCardNumber'$")
	public void user_Clicks_MakePayment_without_DebitCardNumber() throws Throwable {
		objhbpg.setPfcardholder("srinivas");
		objhbpg.setPfdebit("");
		objhbpg.setPfbutton();
	}

	@Then("^display 'Please fill the DebitCardNumber'$")
	public void display_Please_fill_the_DebitCardNumber() throws Throwable {
		 Assert.assertEquals(driver.switchTo().alert().getText(), "Please fill the Debit card Number");
	}
	@When("^user Clicks MakePayment without 'cvv'$")
	public void user_Clicks_MakePayment_without_cvv() throws Throwable {
		objhbpg.setPfcardholder("srinivasBonthu");
		objhbpg.setPfdebit("5656767676767");
		objhbpg.setPfcvv("");
		objhbpg.setPfbutton();
	}

	@Then("^display ' Please fill the CVV'$")
	public void display_Please_fill_the_CVV() throws Throwable {
		Assert.assertEquals(driver.switchTo().alert().getText(), "Please fill the CVV");
	}

	@When("^user Clicks MakePayment Without 'CardExpirationMonth'$")
	public void user_Clicks_MakePayment_Without_CardExpirationMonth() throws Throwable {
		objhbpg.setPfcardholder("srinivasBonthu");
		objhbpg.setPfdebit("5656767676767");
		objhbpg.setPfcvv("486");
		objhbpg.setPfmonth("");
		objhbpg.setPfbutton();
	}

	@Then("^display 'Please fill the ExpirationMonth'$")
	public void display_Please_fill_the_ExpirationMonth() throws Throwable {
		Assert.assertEquals(driver.switchTo().alert().getText(), "Please fill expiration month");
	}

	@When("^user Clicks MakePayment without 'CardExpirationYear'$")
	public void user_Clicks_MakePayment_without_CardExpirationYear() throws Throwable {
		objhbpg.setPfcardholder("srinivasBonthu");
		objhbpg.setPfdebit("5656767676767");
		objhbpg.setPfcvv("486");
		objhbpg.setPfmonth("January");
		objhbpg.setPfyear("");
		objhbpg.setPfbutton();
	}

	@Then("^display 'Please fill the ExpirationYear'$")
	public void display_Please_fill_the_ExpirationYear() throws Throwable {
		Assert.assertEquals(driver.switchTo().alert().getText(), "Please fill the expiration year");
	}

	@When("^user enters valid details$")
	public void user_enters_valid_details() throws Throwable {
		objhbpg.setPfcardholder("srinivasBonthu");
		objhbpg.setPfdebit("5656767676767");
		objhbpg.setPfcvv("486");
		objhbpg.setPfmonth("January");
		objhbpg.setPfyear("2022");
		objhbpg.setPfbutton();
	}
	@Then("^display Page 'Conference Room Booking successfully done!!!'$")
	public void display_success_Page_AND_display_Booking_Completed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Assert.assertEquals(driver.switchTo().alert().getText(), "Conference Room Booking successfully done!!!");
	   
		
	}

}
