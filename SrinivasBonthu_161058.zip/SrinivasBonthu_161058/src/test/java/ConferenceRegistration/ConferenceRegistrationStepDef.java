package ConferenceRegistration;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import PageBean.ConferenceRegistrationPageFactory;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class ConferenceRegistrationStepDef {
	
	private static WebDriver driver;
	private ConferenceRegistrationPageFactory objhbpg;
	String BaseURL,NodeURL;
	

	@Before
	public void beforeLogin()
	{
		System.setProperty("webdriver.chrome.driver","D:\\chromedriver.exe");
		driver = new ChromeDriver();
	}
	
	
	
	
	@Given("^User is on 'ConferenceRegistration' Page$")
	public void user_is_on_ConferenceRegistration_Page() throws Throwable {
		System.out.println("driver = "+driver);
		
		objhbpg = new ConferenceRegistrationPageFactory(driver);
		driver.get("file:///C:/Users/admin/Desktop/Registration/ConferenceRegistartion.html");
	}

	@Then("^Verify The title of the page$")
	public void verify_The_title_of_the_page() throws Throwable {
		String title=driver.getTitle();
		if(title.contentEquals("Conference Registartion")) System.out.println("****** Title Matched");
		else System.out.println("****** Title NOT Matched");
		driver.close();
	}

	@When("^user clicks Next without 'FirstName'$")
	public void user_clicks_Next_without_FirstName() throws Throwable {
		objhbpg.setPffname("");
	    objhbpg.setPfbutton();
	}

	@Then("^display 'Please fill the FirstName'$")
	public void display_Please_fill_the_FirstName() throws Throwable {
		Assert.assertEquals(driver.switchTo().alert().getText(),"Please fill the First Name");
	}

	@When("^user clicks  Next without 'LastName'$")
	public void user_clicks_Next_without_LastName() throws Throwable {
		objhbpg.setPffname("srinu");
		objhbpg.setPflname("");
	    objhbpg.setPfbutton();
	}

	@Then("^display 'Please fill the LastName'$")
	public void display_Please_fill_the_LastName() throws Throwable {
		Assert.assertEquals(driver.switchTo().alert().getText(),"Please fill the Last Name");
	}

	@When("^user enters invalid 'Email'$")
	public void user_enters_invalid_Email() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		objhbpg.setPffname("srinu");
	    objhbpg.setPflname("Bonthu");
	    objhbpg.setPfemail("123");
	    objhbpg.setPfbutton();
	}
	

	@Then("^display 'Please fill the Email'$")
	public void display_Please_fill_the_Email() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    Assert.assertEquals(driver.switchTo().alert().getText(), "Please enter valid Email Id");
	}

	
	@When("^user clicks Next Without 'ContactNo'$")
	public void user_clicks_Next_Without_ContactNo() throws Throwable {
		objhbpg.setPffname("srinu");
	    objhbpg.setPflname("Bonthu");
	    objhbpg.setPfemail("sri@gmail.com");
	    objhbpg.setPfmobile("");
	    objhbpg.setPfbutton();
	}

	@Then("^display 'Please fill the MobileNo'$")
	public void display_Please_fill_the_MobileNo() throws Throwable {
		Assert.assertEquals(driver.switchTo().alert().getText(),"Please fill the Contact No.");
	}

	@When("^user enters invalid 'ContactNo'$")
	public void user_enters_invalid_ContactNo() throws Throwable {
		objhbpg.setPffname("srinu");
	    objhbpg.setPflname("Bonthu");
	    objhbpg.setPfemail("sri@gmail.com");
		objhbpg.setPfmobile("7234457891");
		objhbpg.setPfbutton();
	}

	@Then("^display 'Please Enter Valid Contact no'$")
	public void display_Please_Enter_Valid_Contact_no() throws Throwable {
		Assert.assertEquals(driver.switchTo().alert().getText(),"Please enter valid Contact no.");
	}

	@When("^user clicks Next without 'NoOfPeopleAttending'$")
	public void user_clicks_Next_without_NoOfPeopleAttending() throws Throwable {
		objhbpg.setPffname("srinu");
	    objhbpg.setPflname("Bonthu");
	    objhbpg.setPfemail("sri@gmail.com");
		objhbpg.setPfmobile("9494499914");
		objhbpg.setPfpersons("");
	}

	@Then("^display 'Number of People attending'$")
	public void display_Number_of_People_attending() throws Throwable {
		Assert.assertEquals(driver.switchTo().alert().getText(),"Please fill the Number of people attending");
	}

	@When("^user clicks Next Without 'Building&Room No'$")
	public void user_clicks_Next_Without_Building_Room_No() throws Throwable {

		objhbpg.setPffname("srinu");
	    objhbpg.setPflname("Bonthu");
	    objhbpg.setPfemail("sri@gmail.com");
		objhbpg.setPfmobile("9494499914");
		objhbpg.setPfpersons("2");
		objhbpg.setPfAddress("");
		objhbpg.setPfbutton();
	}

	@Then("^display 'Please fill the Building&Room No'$")
	public void display_Please_fill_the_Building_Room_No() throws Throwable {
		Assert.assertEquals(driver.switchTo().alert().getText(),"Please fill the Building & Room No");
	}

	@When("^user clicks Next Without 'Area Name'$")
	public void user_clicks_Next_Without_Area_Name() throws Throwable {
		objhbpg.setPffname("srinu");
	    objhbpg.setPflname("Bonthu");
	    objhbpg.setPfemail("sri@gmail.com");
		objhbpg.setPfmobile("9494499914");
		objhbpg.setPfpersons("2");
		objhbpg.setPfAddress("ramu 12");
		objhbpg.setPfAddress2("");
		objhbpg.setPfbutton();
	}

	@Then("^display 'Please fill the Area Name'$")
	public void display_Please_fill_the_Area_Name() throws Throwable {
		Assert.assertEquals(driver.switchTo().alert().getText(),"Please fill the Area name");
	}

	@When("^user clicks Next Without 'City'$")
	public void user_clicks_Next_Without_City() throws Throwable {
		objhbpg.setPffname("srinu");
	    objhbpg.setPflname("Bonthu");
	    objhbpg.setPfemail("sri@gmail.com");
		objhbpg.setPfmobile("9494499914");
		objhbpg.setPfpersons("2");
		objhbpg.setPfAddress("ramu 12");
		objhbpg.setPfAddress2("Airoli");
		objhbpg.setPfcity("");
		objhbpg.setPfbutton();
	}

	@Then("^display 'Please select City'$")
	public void display_Please_select_City() throws Throwable {
		Assert.assertEquals(driver.switchTo().alert().getText(),"Please select city");
	}

	@When("^user clicks Next Without 'State'$")
	public void user_clicks_Next_Without_State() throws Throwable {
		objhbpg.setPffname("srinu");
	    objhbpg.setPflname("Bonthu");
	    objhbpg.setPfemail("sri@gmail.com");
		objhbpg.setPfmobile("9494499914");
		objhbpg.setPfpersons("2");
		objhbpg.setPfAddress("ramu 12");
		objhbpg.setPfAddress2("Airoli");
		objhbpg.setPfcity("Pune");
		objhbpg.setPfstate("");
		objhbpg.setPfbutton();
	}

	@Then("^display 'Please select State'$")
	public void display_Please_select_State() throws Throwable {
		Assert.assertEquals(driver.switchTo().alert().getText(),"Please select state");
	}

	@When("^user clicks Next Without selecting 'ConferenceAcccess'$")
	public void user_clicks_Next_Without_selecting_ConferenceAcccess() throws Throwable {
		objhbpg.setPffname("srinu");
	    objhbpg.setPflname("Bonthu");
	    objhbpg.setPfemail("sri@gmail.com");
		objhbpg.setPfmobile("9494499914");
		objhbpg.setPfpersons("2");
		objhbpg.setPfAddress("ramu 12");
		objhbpg.setPfAddress2("Airoli");
		objhbpg.setPfcity("Pune");
		objhbpg.setPfstate("Maharashtra");
		 WebElement radio = driver.findElement(By.name("memberStatus"));
		radio.click();
		 objhbpg.setPfbutton();
	}

	@Then("^display 'Please select Membership'$")
	public void display_Please_select_Membership() throws Throwable {
		Assert.assertEquals(driver.switchTo().alert().getText(),"Please Select MemeberShip status");
	}

	@When("^user enters valid details$")
	public void user_enters_valid_details() throws Throwable {
		objhbpg.setPffname("srinu");
	    objhbpg.setPflname("Bonthu");
	    objhbpg.setPfemail("sri@gmail.com");
		objhbpg.setPfmobile("9494499914");
		objhbpg.setPfpersons("2");
		objhbpg.setPfAddress("ramu 12");
		objhbpg.setPfAddress2("Airoli");
		objhbpg.setPfcity("Pune");
		objhbpg.setPfstate("Maharashtra");
		WebElement radio = driver.findElement(By.name("memberStatus"));
	     radio.click();
	     objhbpg.setPfbutton();
	}

	@Then("^display 'Make Payment Details'$")
	public void display_Make_Payment_Details() throws Throwable {
		Assert.assertEquals(driver.switchTo().alert().getText(),"Personal details are validated.");
		 driver.get("file:///C:/Users/admin/Desktop/Registration/PaymentDetails.html");
	}

}
